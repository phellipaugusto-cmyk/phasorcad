import type { MouseEvent } from "react";

import type { CircuitTerminalSide } from "../../core/CircuitTerminal";
import { TERMINAL_SIZE } from "./circuitGeometry";

interface CircuitTerminalButtonProps {
  terminalId: string;
  side: CircuitTerminalSide;
  elementLabel: string;
  isSelected: boolean;
  onClick: (event: MouseEvent<HTMLButtonElement>) => void;
}

export function CircuitTerminalButton({
  terminalId,
  side,
  elementLabel,
  isSelected,
  onClick,
}: CircuitTerminalButtonProps) {
  return (
    <button
      type="button"
      title={terminalId}
      aria-label={`Selecionar terminal ${side === "left" ? "esquerdo" : "direito"} de ${elementLabel}`}
      onMouseDown={(event) => event.stopPropagation()}
      onClick={onClick}
      style={{
        position: "absolute",
        ...(side === "left"
          ? { left: `${-TERMINAL_SIZE / 2}px` }
          : { right: `${-TERMINAL_SIZE / 2}px` }),
        top: `calc(50% - ${TERMINAL_SIZE / 2}px)`,
        width: `${TERMINAL_SIZE}px`,
        height: `${TERMINAL_SIZE}px`,
        padding: 0,
        border: `2px solid ${isSelected ? "#1d4ed8" : "#111827"}`,
        borderRadius: "50%",
        backgroundColor: isSelected ? "#2563eb" : "#ffffff",
        boxShadow: isSelected
          ? "0 0 0 4px rgba(37, 99, 235, 0.22)"
          : "none",
        cursor: "crosshair",
        zIndex: 3,
      }}
    />
  );
}
