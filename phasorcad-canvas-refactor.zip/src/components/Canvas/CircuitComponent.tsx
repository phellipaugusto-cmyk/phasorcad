import type { MouseEvent } from "react";

import type { CircuitElement } from "../../core/CircuitElement";
import type { CircuitTerminal } from "../../core/CircuitTerminal";
import {
  COMPONENT_HEIGHT,
  COMPONENT_WIDTH,
} from "./circuitGeometry";
import { formatValue, getSymbol, getTerminal } from "./circuitValues";
import { CircuitTerminalButton } from "./CircuitTerminalButton";

interface CircuitComponentProps {
  element: CircuitElement;
  isSelected: boolean;
  isEditing: boolean;
  editingValue: string;
  selectedOriginTerminalId: string | null;
  onStartDrag: (
    event: MouseEvent<HTMLDivElement>,
    element: CircuitElement
  ) => void;
  onSelectElement: (elementId: string) => void;
  onStartEditing: (element: CircuitElement) => void;
  onEditingValueChange: (value: string) => void;
  onSaveValue: (element: CircuitElement) => void;
  onCancelEditing: () => void;
  onSelectTerminal: (
    event: MouseEvent<HTMLButtonElement>,
    element: CircuitElement,
    terminal: CircuitTerminal | undefined
  ) => void;
}

export function CircuitComponent({
  element,
  isSelected,
  isEditing,
  editingValue,
  selectedOriginTerminalId,
  onStartDrag,
  onSelectElement,
  onStartEditing,
  onEditingValueChange,
  onSaveValue,
  onCancelEditing,
  onSelectTerminal,
}: CircuitComponentProps) {
  const leftTerminal = getTerminal(element, "left");
  const rightTerminal = getTerminal(element, "right");

  return (
    <div
      onMouseDown={(event) => onStartDrag(event, element)}
      onClick={() => onSelectElement(element.id)}
      onDoubleClick={() => onStartEditing(element)}
      style={{
        position: "absolute",
        left: element.x,
        top: element.y,
        width: `${COMPONENT_WIDTH}px`,
        minHeight: `${COMPONENT_HEIGHT}px`,
        boxSizing: "border-box",
        textAlign: "center",
        backgroundColor: "#ffffff",
        zIndex: 1,
        border: isSelected
          ? "2px solid #2563eb"
          : "2px solid transparent",
        borderRadius: "6px",
        cursor: isEditing ? "text" : "move",
        userSelect: "none",
      }}
    >
      {leftTerminal ? (
        <CircuitTerminalButton
          terminalId={leftTerminal.id}
          side="left"
          elementLabel={element.label}
          isSelected={selectedOriginTerminalId === leftTerminal.id}
          onClick={(event) => onSelectTerminal(event, element, leftTerminal)}
        />
      ) : null}

      {rightTerminal ? (
        <CircuitTerminalButton
          terminalId={rightTerminal.id}
          side="right"
          elementLabel={element.label}
          isSelected={selectedOriginTerminalId === rightTerminal.id}
          onClick={(event) => onSelectTerminal(event, element, rightTerminal)}
        />
      ) : null}

      <div>
        <strong>{element.label}</strong>
      </div>

      <div style={{ fontSize: "20px", margin: "6px 0" }}>
        {getSymbol(element.type)}
      </div>

      {isEditing ? (
        <input
          autoFocus
          type="number"
          value={editingValue}
          onMouseDown={(event) => event.stopPropagation()}
          onClick={(event) => event.stopPropagation()}
          onChange={(event) => onEditingValueChange(event.target.value)}
          onBlur={() => onSaveValue(element)}
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              onSaveValue(element);
            }

            if (event.key === "Escape") {
              onCancelEditing();
            }
          }}
          style={{ width: "70px" }}
        />
      ) : (
        <div>{formatValue(element.type, element.value)}</div>
      )}
    </div>
  );
}
