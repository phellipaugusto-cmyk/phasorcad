import type { CircuitElement } from "../../core/CircuitElement";

export const CANVAS_WIDTH = 480;
export const CANVAS_HEIGHT = 500;
export const COMPONENT_WIDTH = 80;
export const COMPONENT_HEIGHT = 80;
export const GRID_SIZE = 20;
export const TERMINAL_SIZE = 12;

export interface Point {
  x: number;
  y: number;
}

export function clampElementPosition(x: number, y: number): Point {
  return {
    x: Math.max(0, Math.min(x, CANVAS_WIDTH - COMPONENT_WIDTH)),
    y: Math.max(0, Math.min(y, CANVAS_HEIGHT - COMPONENT_HEIGHT)),
  };
}

export function snapElementPosition(x: number, y: number): Point {
  const snappedX = Math.round(x / GRID_SIZE) * GRID_SIZE;
  const snappedY = Math.round(y / GRID_SIZE) * GRID_SIZE;
  return clampElementPosition(snappedX, snappedY);
}

export function getTerminalPosition(
  element: CircuitElement,
  terminalId: string
): Point {
  const terminal = element.terminals.find((item) => item.id === terminalId);
  const side = terminal?.side ?? "right";

  return {
    x: side === "left" ? element.x : element.x + COMPONENT_WIDTH,
    y: element.y + COMPONENT_HEIGHT / 2,
  };
}

export function createOrthogonalPath(start: Point, end: Point): string {
  const middleX = (start.x + end.x) / 2;
  return `M ${start.x} ${start.y} L ${middleX} ${start.y} L ${middleX} ${end.y} L ${end.x} ${end.y}`;
}
