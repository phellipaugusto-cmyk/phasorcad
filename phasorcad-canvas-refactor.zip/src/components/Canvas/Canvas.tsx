import { useState } from "react";

import type { CircuitConnection } from "../../core/CircuitConnection";
import type { CircuitElement } from "../../core/CircuitElement";
import type { CircuitTerminal } from "../../core/CircuitTerminal";
import type { DragState } from "../../core/DragState";
import { CircuitComponent } from "./CircuitComponent";
import { CircuitConnectionsSvg } from "./CircuitConnectionsSvg";
import { CircuitStatusBar } from "./CircuitStatusBar";
import type { CanvasProps } from "./canvasTypes";
import {
  CANVAS_HEIGHT,
  CANVAS_WIDTH,
  clampElementPosition,
  snapElementPosition,
} from "./circuitGeometry";
import {
  convertEditValue,
  createConnectionId,
  getEditValue,
} from "./circuitValues";

export function Canvas({
  frequency,
  setFrequency,
  sourceVoltage,
  setSourceVoltage,
  elements,
  setElements,
  connections,
  setConnections,
  selectedElementId,
  setSelectedElementId,
  selectedConnectionId,
  setSelectedConnectionId,
  editingElementId,
  setEditingElementId,
}: CanvasProps) {
  const [editingValue, setEditingValue] = useState("");
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [selectedOriginTerminal, setSelectedOriginTerminal] =
    useState<CircuitTerminal | null>(null);
  const [terminalSelectionError, setTerminalSelectionError] =
    useState<string | null>(null);
  const [connectionMessage, setConnectionMessage] =
    useState<string | null>(null);

  function selectElement(elementId: string) {
    setSelectedConnectionId(null);
    setSelectedElementId(elementId);
  }

  function selectConnection(
    event: React.MouseEvent<SVGPathElement>,
    connectionId: string
  ) {
    event.stopPropagation();
    setSelectedElementId(null);
    setEditingElementId(null);
    setSelectedConnectionId(connectionId);
    setSelectedOriginTerminal(null);
    setTerminalSelectionError(null);
    setConnectionMessage(null);
  }

  function saveElementValue(element: CircuitElement) {
    const numericValue = Number(editingValue);

    if (Number.isNaN(numericValue)) {
      setEditingElementId(null);
      return;
    }

    const convertedValue = convertEditValue(element, numericValue);

    setElements(
      elements.map((item) =>
        item.id === element.id
          ? {
              ...item,
              value: convertedValue,
            }
          : item
      )
    );

    if (element.type === "source") {
      setSourceVoltage(convertedValue);
    }

    setEditingElementId(null);
  }

  function startEditing(element: CircuitElement) {
    selectElement(element.id);
    setEditingElementId(element.id);
    setEditingValue(String(getEditValue(element)));
  }

  function startDrag(
    event: React.MouseEvent<HTMLDivElement>,
    element: CircuitElement
  ) {
    if (editingElementId === element.id) {
      return;
    }

    event.preventDefault();
    selectElement(element.id);
    setDragState({
      elementId: element.id,
      offsetX: event.clientX - element.x,
      offsetY: event.clientY - element.y,
    });
  }

  function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
    if (!dragState) {
      return;
    }

    const position = clampElementPosition(
      event.clientX - dragState.offsetX,
      event.clientY - dragState.offsetY
    );

    setElements(
      elements.map((element) =>
        element.id === dragState.elementId
          ? {
              ...element,
              x: position.x,
              y: position.y,
            }
          : element
      )
    );
  }

  function stopDrag() {
    if (dragState) {
      setElements(
        elements.map((element) => {
          if (element.id !== dragState.elementId) {
            return element;
          }

          const position = snapElementPosition(element.x, element.y);
          return {
            ...element,
            x: position.x,
            y: position.y,
          };
        })
      );
    }

    setDragState(null);
  }

  function clearTerminalSelection() {
    setSelectedOriginTerminal(null);
    setTerminalSelectionError(null);
  }

  function startNewTerminalSelection() {
    clearTerminalSelection();
    setConnectionMessage(null);
  }

  function connectionAlreadyExists(
    originTerminalId: string,
    destinationTerminalId: string
  ): boolean {
    return connections.some((connection) => {
      const sameDirection =
        connection.fromTerminalId === originTerminalId &&
        connection.toTerminalId === destinationTerminalId;
      const reverseDirection =
        connection.fromTerminalId === destinationTerminalId &&
        connection.toTerminalId === originTerminalId;
      return sameDirection || reverseDirection;
    });
  }

  function createConnection(
    originTerminal: CircuitTerminal,
    destinationTerminal: CircuitTerminal
  ) {
    if (connectionAlreadyExists(originTerminal.id, destinationTerminal.id)) {
      setTerminalSelectionError(
        "Já existe uma conexão entre esses terminais."
      );
      return;
    }

    const newConnection: CircuitConnection = {
      id: createConnectionId(originTerminal.id, destinationTerminal.id),
      from: originTerminal.elementId,
      to: destinationTerminal.elementId,
      fromTerminalId: originTerminal.id,
      toTerminalId: destinationTerminal.id,
    };

    setConnections([...connections, newConnection]);
    setSelectedConnectionId(newConnection.id);
    setSelectedElementId(null);
    setConnectionMessage(
      `Conexão criada: ${originTerminal.id} → ${destinationTerminal.id}.`
    );
    setSelectedOriginTerminal(null);
    setTerminalSelectionError(null);
  }

  function selectTerminal(
    event: React.MouseEvent<HTMLButtonElement>,
    element: CircuitElement,
    terminal: CircuitTerminal | undefined
  ) {
    event.stopPropagation();

    if (!terminal) {
      return;
    }

    setSelectedConnectionId(null);
    setSelectedElementId(element.id);
    setEditingElementId(null);
    setTerminalSelectionError(null);
    setConnectionMessage(null);

    if (!selectedOriginTerminal) {
      setSelectedOriginTerminal(terminal);
      return;
    }

    if (terminal.id === selectedOriginTerminal.id) {
      clearTerminalSelection();
      return;
    }

    if (terminal.elementId === selectedOriginTerminal.elementId) {
      setTerminalSelectionError(
        "Não é permitido conectar dois terminais do mesmo componente nesta etapa."
      );
      return;
    }

    createConnection(selectedOriginTerminal, terminal);
  }

  return (
    <div>
      <h2>Canvas do Circuito</h2>

      <div
        style={{
          border: "1px solid #ccc",
          padding: "8px",
          marginBottom: "10px",
          backgroundColor: "#f8f8f8",
          textAlign: "center",
        }}
      >
        <div>
          <strong>Configurações do Circuito</strong>
        </div>

        <div style={{ marginTop: "4px" }}>
          <label>
            Fonte:{" "}
            <input
              type="number"
              value={sourceVoltage}
              onChange={(event) => setSourceVoltage(Number(event.target.value))}
              style={{ width: "80px" }}
            />{" "}
            V
          </label>
        </div>

        <div style={{ marginTop: "4px" }}>
          <label>
            Frequência:{" "}
            <input
              type="number"
              value={frequency}
              onChange={(event) => setFrequency(Number(event.target.value))}
              style={{ width: "80px" }}
            />{" "}
            Hz
          </label>
        </div>
      </div>

      <CircuitStatusBar
        error={terminalSelectionError}
        message={connectionMessage}
        selectedOriginTerminalId={selectedOriginTerminal?.id ?? null}
        selectedConnectionId={selectedConnectionId}
        onCancel={clearTerminalSelection}
        onNewConnection={startNewTerminalSelection}
      />

      <div
        style={{
          border: "2px dashed gray",
          width: `${CANVAS_WIDTH}px`,
          height: `${CANVAS_HEIGHT}px`,
          position: "relative",
          overflow: "hidden",
          backgroundColor: "#ffffff",
        }}
        onMouseMove={handleMouseMove}
        onMouseUp={stopDrag}
        onMouseLeave={stopDrag}
      >
        <CircuitConnectionsSvg
          connections={connections}
          elements={elements}
          selectedConnectionId={selectedConnectionId}
          onSelectConnection={selectConnection}
        />

        {elements.map((element) => (
          <CircuitComponent
            key={element.id}
            element={element}
            isSelected={selectedElementId === element.id}
            isEditing={editingElementId === element.id}
            editingValue={editingValue}
            selectedOriginTerminalId={selectedOriginTerminal?.id ?? null}
            onStartDrag={startDrag}
            onSelectElement={selectElement}
            onStartEditing={startEditing}
            onEditingValueChange={setEditingValue}
            onSaveValue={saveElementValue}
            onCancelEditing={() => setEditingElementId(null)}
            onSelectTerminal={selectTerminal}
          />
        ))}
      </div>
    </div>
  );
}
