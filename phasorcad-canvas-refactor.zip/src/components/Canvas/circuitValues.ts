import type { CircuitElement } from "../../core/CircuitElement";
import type {
  CircuitTerminal,
  CircuitTerminalSide,
} from "../../core/CircuitTerminal";

export function formatValue(
  type: CircuitElement["type"],
  value: number
): string {
  switch (type) {
    case "resistor":
      return `${value} Ω`;
    case "capacitor":
      return `${value * 1_000_000} µF`;
    case "inductor":
      return `${value * 1000} mH`;
    case "source":
      return `${value} V`;
    default:
      return `${value}`;
  }
}

export function getEditValue(element: CircuitElement): number {
  switch (element.type) {
    case "capacitor":
      return element.value * 1_000_000;
    case "inductor":
      return element.value * 1000;
    default:
      return element.value;
  }
}

export function convertEditValue(
  element: CircuitElement,
  value: number
): number {
  switch (element.type) {
    case "capacitor":
      return Math.max(value, 0.000001) / 1_000_000;
    case "inductor":
      return Math.max(value, 0.000001) / 1000;
    case "resistor":
      return Math.max(value, 0.000001);
    case "source":
      return Math.max(value, 0);
    default:
      return value;
  }
}

export function getSymbol(type: CircuitElement["type"]): string {
  switch (type) {
    case "resistor":
      return "/\\/\\/\\";
    case "capacitor":
      return "| |";
    case "inductor":
      return "∿∿∿";
    case "source":
      return "(~)";
    default:
      return "?";
  }
}

export function getTerminal(
  element: CircuitElement,
  side: CircuitTerminalSide
): CircuitTerminal | undefined {
  return element.terminals.find((terminal) => terminal.side === side);
}

export function createConnectionId(
  originTerminalId: string,
  destinationTerminalId: string
): string {
  const safeOrigin = originTerminalId.replace(/[^a-zA-Z0-9]/g, "-");
  const safeDestination = destinationTerminalId.replace(/[^a-zA-Z0-9]/g, "-");
  return `connection-${safeOrigin}-${safeDestination}-${Date.now()}`;
}
