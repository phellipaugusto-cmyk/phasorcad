import type { MouseEvent } from "react";

import type { CircuitConnection } from "../../core/CircuitConnection";
import type { CircuitElement } from "../../core/CircuitElement";
import {
  createOrthogonalPath,
  getTerminalPosition,
} from "./circuitGeometry";

interface CircuitConnectionsSvgProps {
  connections: CircuitConnection[];
  elements: CircuitElement[];
  selectedConnectionId: string | null;
  onSelectConnection: (
    event: MouseEvent<SVGPathElement>,
    connectionId: string
  ) => void;
}

export function CircuitConnectionsSvg({
  connections,
  elements,
  selectedConnectionId,
  onSelectConnection,
}: CircuitConnectionsSvgProps) {
  return (
    <svg
      aria-label="Conexões do circuito"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        zIndex: 0,
      }}
    >
      {connections.map((connection) => {
        const from = elements.find((element) => element.id === connection.from);
        const to = elements.find((element) => element.id === connection.to);

        if (!from || !to) {
          return null;
        }

        const start = getTerminalPosition(from, connection.fromTerminalId);
        const end = getTerminalPosition(to, connection.toTerminalId);
        const pathData = createOrthogonalPath(start, end);
        const isSelected = selectedConnectionId === connection.id;

        return (
          <g key={connection.id}>
            <path
              d={pathData}
              fill="none"
              stroke="transparent"
              strokeWidth={16}
              cursor="pointer"
              onMouseDown={(event) => event.stopPropagation()}
              onClick={(event) => onSelectConnection(event, connection.id)}
            />

            <path
              d={pathData}
              fill="none"
              stroke={isSelected ? "#2563eb" : "#222222"}
              strokeWidth={isSelected ? 4 : 2}
              pointerEvents="none"
            />
          </g>
        );
      })}
    </svg>
  );
}
