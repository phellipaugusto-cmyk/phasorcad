import {
  useEffect,
  useState,
} from "react";

import type {
  CircuitElement,
  CircuitElementType,
} from "./core/CircuitElement";

import type {
  CircuitConnection,
} from "./core/CircuitConnection";

import type {
  CircuitResult,
} from "./core/CircuitResult";

import {
  createCircuitTerminals,
} from "./core/CircuitTerminal";

import {
  Complex,
} from "./math/Complex";

import {
  defaultCircuitModel,
} from "./data/defaultCircuitModel";

import {
  CircuitBuilder,
} from "./solver/CircuitBuilder";

import {
  ACAnalyzer,
} from "./solver/ACAnalyzer";

import {
  isCircuitClosed,
} from "./solver/CircuitTopology";

import {
  Toolbox,
} from "./components/Toolbox/Toolbox";

import {
  Canvas,
} from "./components/Canvas/Canvas";

import {
  ResultsPanel,
} from "./components/ResultsPanel/ResultsPanel";

const ELEMENTS_STORAGE_KEY =
  "phasorcad-elements";

const CONNECTIONS_STORAGE_KEY =
  "phasorcad-connections";

const validElementTypes:
  CircuitElementType[] = [
    "source",
    "resistor",
    "capacitor",
    "inductor",
  ];

function isElementType(
  value: unknown
): value is CircuitElementType {
  return (
    typeof value === "string" &&
    validElementTypes.includes(
      value as CircuitElementType
    )
  );
}

function migrateElement(
  value: unknown
): CircuitElement | null {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return null;
  }

  const candidate =
    value as Partial<CircuitElement>;

  if (
    typeof candidate.id !== "string" ||
    !isElementType(
      candidate.type
    ) ||
    typeof candidate.label !== "string" ||
    typeof candidate.value !== "number" ||
    !Number.isFinite(
      candidate.value
    ) ||
    typeof candidate.x !== "number" ||
    !Number.isFinite(
      candidate.x
    ) ||
    typeof candidate.y !== "number" ||
    !Number.isFinite(
      candidate.y
    )
  ) {
    return null;
  }

  return {
    id:
      candidate.id,

    type:
      candidate.type,

    label:
      candidate.label,

    value:
      candidate.value,

    x:
      candidate.x,

    y:
      candidate.y,

    terminals:
      createCircuitTerminals(
        candidate.id
      ),
  };
}

function loadElements(): CircuitElement[] {
  const saved =
    localStorage.getItem(
      ELEMENTS_STORAGE_KEY
    );

  if (!saved) {
    return defaultCircuitModel.elements;
  }

  try {
    const parsed: unknown =
      JSON.parse(
        saved
      );

    if (!Array.isArray(parsed)) {
      return defaultCircuitModel.elements;
    }

    if (parsed.length === 0) {
      return [];
    }

    const migratedElements =
      parsed
        .map(
          migrateElement
        )
        .filter(
          (
            element
          ): element is CircuitElement =>
            element !== null
        );

    if (
      migratedElements.length === 0
    ) {
      return defaultCircuitModel.elements;
    }

    return migratedElements;
  } catch {
    return defaultCircuitModel.elements;
  }
}

function migrateConnection(
  value: unknown
): CircuitConnection | null {
  if (
    typeof value !== "object" ||
    value === null
  ) {
    return null;
  }

  const candidate =
    value as Partial<CircuitConnection>;

  if (
    typeof candidate.id !== "string" ||
    typeof candidate.from !== "string" ||
    typeof candidate.to !== "string" ||
    typeof candidate.fromTerminalId !== "string" ||
    typeof candidate.toTerminalId !== "string"
  ) {
    return null;
  }

  return {
    id:
      candidate.id,

    from:
      candidate.from,

    to:
      candidate.to,

    fromTerminalId:
      candidate.fromTerminalId,

    toTerminalId:
      candidate.toTerminalId,
  };
}

function loadConnections(): CircuitConnection[] {
  const saved =
    localStorage.getItem(
      CONNECTIONS_STORAGE_KEY
    );

  if (!saved) {
    return defaultCircuitModel.connections;
  }

  try {
    const parsed: unknown =
      JSON.parse(
        saved
      );

    if (!Array.isArray(parsed)) {
      return defaultCircuitModel.connections;
    }

    if (parsed.length === 0) {
      return [];
    }

    return parsed
      .map(
        migrateConnection
      )
      .filter(
        (
          connection
        ): connection is CircuitConnection =>
          connection !== null
      );
  } catch {
    return defaultCircuitModel.connections;
  }
}

function createEmptyResult(): CircuitResult {
  return {
    zeq:
      new Complex(
        0,
        0
      ),

    current:
      new Complex(
        0,
        0
      ),

    activePower:
      0,

    reactivePower:
      0,

    apparentPower:
      0,

    powerFactor:
      0,
  };
}

function App() {
  const [
    elements,
    setElements,
  ] =
    useState<CircuitElement[]>(
      loadElements
    );

  const [
    connections,
    setConnections,
  ] =
    useState<CircuitConnection[]>(
      loadConnections
    );

  const [
    frequency,
    setFrequency,
  ] =
    useState(
      defaultCircuitModel.frequency
    );

  const initialSource =
    elements.find(
      (element) =>
        element.type === "source"
    );

  const [
    sourceVoltage,
    setSourceVoltage,
  ] =
    useState(
      initialSource?.value ?? 0
    );

  const [
    selectedElementId,
    setSelectedElementId,
  ] =
    useState<string | null>(
      null
    );

  const [
    selectedConnectionId,
    setSelectedConnectionId,
  ] =
    useState<string | null>(
      null
    );

  const [
    editingElementId,
    setEditingElementId,
  ] =
    useState<string | null>(
      null
    );

  useEffect(() => {
    localStorage.setItem(
      ELEMENTS_STORAGE_KEY,
      JSON.stringify(
        elements
      )
    );
  }, [elements]);

  useEffect(() => {
    localStorage.setItem(
      CONNECTIONS_STORAGE_KEY,
      JSON.stringify(
        connections
      )
    );
  }, [connections]);

  const selectedElement =
    elements.find(
      (element) =>
        element.id ===
        selectedElementId
    ) ?? null;

  const selectedConnection =
    connections.find(
      (connection) =>
        connection.id ===
        selectedConnectionId
    ) ?? null;

  const sourceElement =
    elements.find(
      (element) =>
        element.type === "source"
    );

  const hasSource =
    sourceElement !== undefined;

  const circuitIsClosed =
    isCircuitClosed(
      elements,
      connections
    );

  const safeFrequency =
    Math.max(
      frequency,
      0.000001
    );

  const connectedElementIds =
    new Set<string>();

  connections.forEach(
    (connection) => {
      connectedElementIds.add(
        connection.from
      );

      connectedElementIds.add(
        connection.to
      );
    }
  );

  const selectedElementIsProtected =
    selectedElement
      ? connectedElementIds.has(
          selectedElement.id
        )
      : false;

  /*
   * O cálculo ainda utiliza o analisador série atual.
   * A topologia real agora controla se o circuito
   * está aberto ou fechado.
   *
   * Circuitos paralelos e mistos serão tratados pelo
   * futuro solver nodal.
   */
  const analysisElementIds =
    new Set<string>();

  connections.forEach(
    (connection) => {
      analysisElementIds.add(
        connection.from
      );

      analysisElementIds.add(
        connection.to
      );
    }
  );

  const analysisElements =
    elements.filter(
      (element) =>
        analysisElementIds.has(
          element.id
        )
    );

  const circuitForAnalysis = {
    ...defaultCircuitModel,

    frequency:
      safeFrequency,

    elements:
      analysisElements,

    connections,
  };

  const impedances =
    CircuitBuilder.buildImpedances(
      circuitForAnalysis,
      safeFrequency
    );

  const canAnalyze =
    circuitIsClosed &&
    hasSource &&
    sourceVoltage > 0 &&
    impedances.length > 0;

  const result: CircuitResult =
    canAnalyze
      ? ACAnalyzer.analyzeSeriesCircuit(
          sourceVoltage,
          impedances
        )
      : createEmptyResult();

  function newCircuit() {
    const shouldCreate =
      window.confirm(
        "Criar um novo circuito? Todos os componentes e conexões atuais serão removidos."
      );

    if (!shouldCreate) {
      return;
    }

    localStorage.removeItem(
      ELEMENTS_STORAGE_KEY
    );

    localStorage.removeItem(
      CONNECTIONS_STORAGE_KEY
    );

    setElements(
      []
    );

    setConnections(
      []
    );

    setSelectedElementId(
      null
    );

    setSelectedConnectionId(
      null
    );

    setEditingElementId(
      null
    );

    setSourceVoltage(
      0
    );

    setFrequency(
      defaultCircuitModel.frequency
    );
  }

  function getNextElementId(
    type: CircuitElement["type"]
  ): string {
    const prefixes: Record<
      CircuitElement["type"],
      string
    > = {
      source: "V",
      resistor: "R",
      capacitor: "C",
      inductor: "L",
    };

    const prefix =
      prefixes[type];

    const existingNumbers =
      elements
        .filter(
          (element) =>
            element.type === type
        )
        .map(
          (element) => {
            const expression =
              new RegExp(
                `^${prefix}`
              );

            const number =
              Number(
                element.id.replace(
                  expression,
                  ""
                )
              );

            return Number.isFinite(
              number
            )
              ? number
              : 0;
          }
        );

    const highestNumber =
      existingNumbers.length > 0
        ? Math.max(
            ...existingNumbers
          )
        : 0;

    return `${prefix}${highestNumber + 1}`;
  }

  function getNewElementPosition(
    type: CircuitElement["type"]
  ): {
    x: number;
    y: number;
  } {
    const index =
      elements.length;

    const column =
      index % 4;

    const row =
      Math.floor(
        index / 4
      );

    const typeOffset: Record<
      CircuitElement["type"],
      number
    > = {
      source: 0,
      resistor: 0,
      capacitor: 20,
      inductor: 40,
    };

    return {
      x:
        40 +
        column * 100,

      y:
        Math.min(
          80 +
            row * 100 +
            typeOffset[type],
          400
        ),
    };
  }

  function addElement(
    type: CircuitElement["type"],
    defaultValue: number
  ) {
    const id =
      getNextElementId(
        type
      );

    const position =
      getNewElementPosition(
        type
      );

    const newElement: CircuitElement = {
      id,
      type,
      label:
        id,
      value:
        defaultValue,
      x:
        position.x,
      y:
        position.y,
      terminals:
        createCircuitTerminals(
          id
        ),
    };

    setElements(
      (
        currentElements
      ) => [
        ...currentElements,
        newElement,
      ]
    );

    setSelectedConnectionId(
      null
    );

    setSelectedElementId(
      id
    );

    setEditingElementId(
      null
    );
  }

  function addSource() {
    if (hasSource) {
      return;
    }

    const initialVoltage =
      220;

    addElement(
      "source",
      initialVoltage
    );

    setSourceVoltage(
      initialVoltage
    );
  }

  function addResistor() {
    addElement(
      "resistor",
      100
    );
  }

  function addCapacitor() {
    addElement(
      "capacitor",
      100 / 1_000_000
    );
  }

  function addInductor() {
    addElement(
      "inductor",
      100 / 1000
    );
  }

  function removeSelectedElement() {
    if (!selectedElement) {
      return;
    }

    if (
      connectedElementIds.has(
        selectedElement.id
      )
    ) {
      return;
    }

    const elementId =
      selectedElement.id;

    const removingSource =
      selectedElement.type === "source";

    setElements(
      (
        currentElements
      ) =>
        currentElements.filter(
          (element) =>
            element.id !== elementId
        )
    );

    setConnections(
      (
        currentConnections
      ) =>
        currentConnections.filter(
          (connection) =>
            connection.from !==
              elementId &&
            connection.to !==
              elementId
        )
    );

    if (removingSource) {
      setSourceVoltage(
        0
      );
    }

    setSelectedElementId(
      null
    );

    setSelectedConnectionId(
      null
    );

    setEditingElementId(
      null
    );
  }

  function removeSelectedConnection() {
    if (!selectedConnection) {
      return;
    }

    const connectionId =
      selectedConnection.id;

    setConnections(
      (
        currentConnections
      ) =>
        currentConnections.filter(
          (connection) =>
            connection.id !==
            connectionId
        )
    );

    setSelectedConnectionId(
      null
    );
  }

  function getDisplayValue(): number {
    if (!selectedElement) {
      return 0;
    }

    switch (
      selectedElement.type
    ) {
      case "capacitor":
        return (
          selectedElement.value *
          1_000_000
        );

      case "inductor":
        return (
          selectedElement.value *
          1000
        );

      default:
        return selectedElement.value;
    }
  }

  function getUnit(): string {
    if (!selectedElement) {
      return "";
    }

    switch (
      selectedElement.type
    ) {
      case "source":
        return "V";

      case "resistor":
        return "Ω";

      case "capacitor":
        return "µF";

      case "inductor":
        return "mH";

      default:
        return "";
    }
  }

  function updateSelectedElement(
    value: number
  ) {
    if (!selectedElement) {
      return;
    }

    let convertedValue =
      value;

    switch (
      selectedElement.type
    ) {
      case "capacitor":
        convertedValue =
          Math.max(
            value,
            0.000001
          ) / 1_000_000;
        break;

      case "inductor":
        convertedValue =
          Math.max(
            value,
            0.000001
          ) / 1000;
        break;

      case "resistor":
        convertedValue =
          Math.max(
            value,
            0.000001
          );
        break;

      case "source":
        convertedValue =
          Math.max(
            value,
            0
          );

        setSourceVoltage(
          convertedValue
        );
        break;
    }

    setElements(
      (
        currentElements
      ) =>
        currentElements.map(
          (element) =>
            element.id ===
            selectedElement.id
              ? {
                  ...element,

                  value:
                    convertedValue,
                }
              : element
        )
    );
  }

  return (
    <div
      style={{
        display:
          "grid",

        gridTemplateColumns:
          "220px 1fr 300px",

        height:
          "100vh",
      }}
    >
      <div
        style={{
          borderRight:
            "1px solid #ccc",

          padding:
            "10px",
        }}
      >
        <Toolbox
          onNewCircuit={
            newCircuit
          }
          onAddSource={
            addSource
          }
          onAddResistor={
            addResistor
          }
          onAddCapacitor={
            addCapacitor
          }
          onAddInductor={
            addInductor
          }
          hasSource={
            hasSource
          }
        />
      </div>

      <div
        style={{
          padding:
            "10px",
        }}
      >
        <div
          style={{
            marginBottom:
              "10px",

            padding:
              "10px",

            border:
              circuitIsClosed
                ? "1px solid #16a34a"
                : "1px solid #dc2626",

            borderRadius:
              "6px",

            backgroundColor:
              circuitIsClosed
                ? "#f0fdf4"
                : "#fef2f2",

            color:
              circuitIsClosed
                ? "#15803d"
                : "#b91c1c",

            fontWeight:
              600,
          }}
        >
          Estado do circuito:
          {" "}

          {circuitIsClosed
            ? "FECHADO"
            : "ABERTO"}

          {!circuitIsClosed ? (
            <div
              style={{
                marginTop:
                  "4px",

                fontSize:
                  "12px",

                fontWeight:
                  400,
              }}
            >
              Não existe um caminho completo entre os dois terminais da fonte. A corrente é zero.
            </div>
          ) : (
            <div
              style={{
                marginTop:
                  "4px",

                fontSize:
                  "12px",

                fontWeight:
                  400,
              }}
            >
              Existe um caminho elétrico fechado entre os dois terminais da fonte.
            </div>
          )}
        </div>

        <Canvas
          frequency={
            frequency
          }
          setFrequency={
            setFrequency
          }
          sourceVoltage={
            sourceVoltage
          }
          setSourceVoltage={
            setSourceVoltage
          }
          elements={
            elements
          }
          setElements={
            setElements
          }
          connections={
            connections
          }
          setConnections={
            setConnections
          }
          selectedElementId={
            selectedElementId
          }
          setSelectedElementId={
            setSelectedElementId
          }
          selectedConnectionId={
            selectedConnectionId
          }
          setSelectedConnectionId={
            setSelectedConnectionId
          }
          editingElementId={
            editingElementId
          }
          setEditingElementId={
            setEditingElementId
          }
        />
      </div>

      <div
        style={{
          borderLeft:
            "1px solid #ccc",

          padding:
            "10px",
        }}
      >
        <ResultsPanel
          result={
            result
          }
        />

        <hr />

        {selectedConnection ? (
          <div>
            <h3>
              Conexão Selecionada
            </h3>

            <div>
              <strong>
                Origem:
              </strong>{" "}
              {
                selectedConnection
                  .fromTerminalId
              }
            </div>

            <div
              style={{
                marginTop:
                  "6px",
              }}
            >
              <strong>
                Destino:
              </strong>{" "}
              {
                selectedConnection
                  .toTerminalId
              }
            </div>

            <div
              style={{
                marginTop:
                  "16px",
              }}
            >
              <button
                type="button"
                onClick={
                  removeSelectedConnection
                }
                style={{
                  color:
                    "#b91c1c",

                  cursor:
                    "pointer",
                }}
              >
                Remover conexão
              </button>
            </div>

            <p
              style={{
                marginTop:
                  "8px",

                color:
                  "#666",

                fontSize:
                  "12px",
              }}
            >
              A remoção do fio não remove os componentes.
            </p>
          </div>
        ) : selectedElement ? (
          <div>
            <h3>
              Componente Selecionado
            </h3>

            <div>
              <strong>
                ID:
              </strong>{" "}
              {
                selectedElement.id
              }
            </div>

            <div>
              <strong>
                Tipo:
              </strong>{" "}
              {
                selectedElement.type
              }
            </div>

            <div
              style={{
                marginTop:
                  "10px",
              }}
            >
              <label>
                <strong>
                  Valor:
                </strong>
              </label>

              <br />

              <input
                type="number"
                value={
                  getDisplayValue()
                }
                onChange={(
                  event
                ) =>
                  updateSelectedElement(
                    Number(
                      event.target
                        .value
                    )
                  )
                }
                style={{
                  width:
                    "100px",

                  marginTop:
                    "4px",
                }}
              />

              {" "}
              {getUnit()}
            </div>

            <div
              style={{
                marginTop:
                  "16px",
              }}
            >
              <button
                type="button"
                onClick={
                  removeSelectedElement
                }
                disabled={
                  selectedElementIsProtected
                }
                title={
                  selectedElementIsProtected
                    ? "Este componente possui conexão e não pode ser removido."
                    : "Remover componente selecionado."
                }
                style={{
                  color:
                    selectedElementIsProtected
                      ? "#777"
                      : "#b91c1c",

                  cursor:
                    selectedElementIsProtected
                      ? "not-allowed"
                      : "pointer",
                }}
              >
                Remover componente
              </button>
            </div>

            {selectedElementIsProtected ? (
              <p
                style={{
                  marginTop:
                    "8px",

                  color:
                    "#666",

                  fontSize:
                    "12px",
                }}
              >
                O componente possui conexão e está protegido.
              </p>
            ) : (
              <p
                style={{
                  marginTop:
                    "8px",

                  color:
                    "#666",

                  fontSize:
                    "12px",
                }}
              >
                O componente está desconectado e pode ser removido.
              </p>
            )}
          </div>
        ) : (
          <div>
            <h3>
              Seleção
            </h3>

            Nenhum componente ou conexão selecionado
          </div>
        )}
      </div>
    </div>
  );
}

export default App;